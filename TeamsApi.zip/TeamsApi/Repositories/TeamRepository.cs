using Microsoft.EntityFrameworkCore;

public class TeamRepository : ITeamRepository
{
    private readonly AppDbContext _db;
    public TeamRepository(AppDbContext db) => _db = db;

    public async Task<IEnumerable<Team>> GetAllAsync() =>
        await _db.Teams.AsNoTracking().ToListAsync();

    public async Task<Team?> GetAsync(int id) =>
        await _db.Teams.FindAsync(id);

    public async Task CreateAsync(Team team)
    {
        _db.Teams.Add(team);
        await _db.SaveChangesAsync();
    }

    public async Task UpdateAsync(Team team)
    {
        _db.Teams.Update(team);
        await _db.SaveChangesAsync();
    }

    public async Task DeleteAsync(int id)
    {
        var entity = await _db.Teams.FindAsync(id);
        if (entity is null) return;
        _db.Teams.Remove(entity);
        await _db.SaveChangesAsync();
    }

    public async Task<IEnumerable<Team>> GetByCityAsync(string city)
    {
        // Сравнение без учёта регистра выполняется в памяти:
        // SQLite не умеет приводить кириллицу к нижнему регистру на стороне БД.
        var all = await _db.Teams.AsNoTracking().ToListAsync();
        return all.Where(t => string.Equals(t.City, city, StringComparison.OrdinalIgnoreCase));
    }
}
