public interface ITeamRepository
{
    Task<IEnumerable<Team>> GetAllAsync();
    Task<Team?> GetAsync(int id);
    Task CreateAsync(Team team);
    Task UpdateAsync(Team team);
    Task DeleteAsync(int id);

    // Часть 2: поиск по городу
    Task<IEnumerable<Team>> GetByCityAsync(string city);
}
