using AutoMapper;
using Microsoft.AspNetCore.Mvc;

[ApiController]
[Route("api/team")]
public class TeamController : ControllerBase
{
    private readonly ITeamRepository _repo;
    private readonly IMapper _mapper;

    public TeamController(ITeamRepository repo, IMapper mapper)
    {
        _repo = repo;
        _mapper = mapper;
    }

    // GET /api/team
    [HttpGet]
    public async Task<ActionResult<ReturnResult<IEnumerable<TeamDto>>>> GetAll()
    {
        var teams = await _repo.GetAllAsync();
        return Ok(ReturnResult<IEnumerable<TeamDto>>
            .Ok(_mapper.Map<IEnumerable<TeamDto>>(teams)));
    }

    // GET /api/team/{id}
    [HttpGet("{id:int}")]
    public async Task<ActionResult<ReturnResult<TeamDto>>> Get(int id)
    {
        var team = await _repo.GetAsync(id);
        if (team is null)
            return NotFound(ReturnResult<TeamDto>.Fail($"Команда {id} не найдена"));

        return Ok(ReturnResult<TeamDto>.Ok(_mapper.Map<TeamDto>(team)));
    }

    // GET /api/team/city/{city}
    [HttpGet("city/{city}")]
    public async Task<ActionResult<ReturnResult<IEnumerable<TeamDto>>>> GetByCity(string city)
    {
        var teams = await _repo.GetByCityAsync(city);
        return Ok(ReturnResult<IEnumerable<TeamDto>>
            .Ok(_mapper.Map<IEnumerable<TeamDto>>(teams)));
    }

    // POST /api/team
    [HttpPost]
    public async Task<ActionResult<ReturnResult<TeamDto>>> Create(TeamDto dto)
    {
        var team = _mapper.Map<Team>(dto);
        team.Id = 0;
        await _repo.CreateAsync(team);

        var result = ReturnResult<TeamDto>.Ok(_mapper.Map<TeamDto>(team));
        return CreatedAtAction(nameof(Get), new { id = team.Id }, result);
    }

    // PUT /api/team/{id}
    [HttpPut("{id:int}")]
    public async Task<ActionResult<ReturnResult<TeamDto>>> Update(int id, TeamDto dto)
    {
        var team = await _repo.GetAsync(id);
        if (team is null)
            return NotFound(ReturnResult<TeamDto>.Fail($"Команда {id} не найдена"));

        _mapper.Map(dto, team);   // Description в DTO нет, поэтому остаётся прежним
        team.Id = id;
        await _repo.UpdateAsync(team);

        return Ok(ReturnResult<TeamDto>.Ok(_mapper.Map<TeamDto>(team)));
    }

    // DELETE /api/team/{id}
    [HttpDelete("{id:int}")]
    public async Task<ActionResult<ReturnResult<bool>>> Delete(int id)
    {
        if (await _repo.GetAsync(id) is null)
            return NotFound(ReturnResult<bool>.Fail($"Команда {id} не найдена"));

        await _repo.DeleteAsync(id);
        return Ok(ReturnResult<bool>.Ok(true));
    }
}
