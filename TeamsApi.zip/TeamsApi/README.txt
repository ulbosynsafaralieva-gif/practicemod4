Запуск (из папки, где лежит TeamsApi.csproj):

  dotnet restore
  dotnet ef migrations add InitialCreate
  dotnet run

Откройте адрес из консоли (http://localhost:XXXX) - откроется /swagger.
